﻿Se tiver o GCC e o Git Bash, 
	execute o Git Bash na pasta (clicar com o botão direito do mouse no diretório e "Git Bash Here") 
	e executar "sh compilarParam.sh <nomeDoEx>"; Exemplo :"sh compilarParam.sh Ex1"