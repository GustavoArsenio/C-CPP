#include <stdio.h>

#ifndef UTIL_H
#define UTIL_H

#define true 1
#define false 0

FILE *util_abre_arq(char *nome);

#endif